<div class="footer">
			<div class="wthree-copyright">
			  <p>© <?php echo date('Y');?> Food Waste Management System. All rights reserved.</p>
			</div>
		  </div>